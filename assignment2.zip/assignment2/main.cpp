//Assignment 2
//CS3100
//a01886175
//Shaun Chap

#include <iostream>
#include <string>
#include <cmath>
#include "compute_fib.hpp"
#include "compute_e.hpp"
#include "compute_pi.hpp"

using namespace std;

int main(int argc, char* argv[]){
    
    //creating objects
    compute_e computeE;
    compute_fib computeFIB;
    compute_pi computePI;
    
	// info
	cout << "assignment 2:" << endl;
	cout << "use param: -fib(fibonacci), -e, -pi, then a number" << endl;
	cout << "-----" << endl;
    
    // displays params
	for(int param = 0; param < argc; param++){
		cout << "param " << (param + 1) << ": " << argv[param] << endl;
	}
	cout << "-----" << endl;
	
	string compute = argv[1];
	int num = stoi(argv[2]);
	
	if(compute == "-fib" && num >= 0 && num <= 40){
		cout << "the fibonacci of " << num << " is..." << endl;
		cout << computeFIB.findfib(num) << endl;
	}
	else if(compute == "-e" && num >= 1 && num <= 30){
 		cout << "the value of e using " << num << " iterations..." << endl;
 		cout << computeE.finde(num) << endl;
	}
	else if(compute == "-pi" && num >=1 && num <=10){
        cout << "pi to " << num << " digits..." << endl;
        cout << computePI.findpi(num) << endl;
	}
	else{
		cout << "Try again?" << endl;
	}

    
	
    return 0;
}