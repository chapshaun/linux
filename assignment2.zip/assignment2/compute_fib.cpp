#include "compute_fib.hpp"

// Credit: https://www.ics.uci.edu/~eppstein/161/960109.html
int compute_fib::findfib(int n){
    if (n <= 2){
		return 1;
	}
	else{
		return findfib(n - 1) + findfib(n - 2);
	}
}