#ifndef _COMPUTE_FIB_
#define _COMPUTE_FIB_

#include <string>
#include <cmath>

using namespace std;

class compute_fib
{
public:
    int findfib(int n);    

    
private:
};
#endif