#ifndef _COMPUTE_PI_
#define _COMPUTE_PI_

#include <string>
#include <cmath>

using namespace std;

class compute_pi
{
public:
    string findpi(int n);    
    
private:
};
#endif