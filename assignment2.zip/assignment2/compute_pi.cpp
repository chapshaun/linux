#include "compute_pi.hpp"
#include <string>

string compute_pi::findpi(int n){
    //string of pi numbers
    string pi = "3.141592653589793";
    //outputing number of digits after decimal in pi string
	// + 2 for including '3 and .'
	string final_pi = pi.substr(0, n + 2);

    return final_pi;		
}