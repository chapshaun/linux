#ifndef _COMPUTE_E_
#define _COMPUTE_E_

#include <string>
#include <cmath>

using namespace std;

class compute_e
{
public:
    float finde(int n);
private:
};
#endif