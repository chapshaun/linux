#include "compute_e.hpp"
#include <cmath>

float compute_e::finde(int n){
    float e = 0.00;
    double count = 1;
    for(int i = 1; i <= n; i++){
        //taylor series
        e = e + (1/count);
        count = i * count;
    }
    return e;
}